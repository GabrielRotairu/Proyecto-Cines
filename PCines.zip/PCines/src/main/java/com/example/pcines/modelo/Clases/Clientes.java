package com.example.pcines.modelo.Clases;

public class Clientes {
    private int id_clientes;
    private String nombre;
    private String apellidos;
    private String contraseña;
    private String email;

    public Clientes(int id_clientes, String nombre, String apellidos, String contraseña, String email) {
        this.id_clientes = id_clientes;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.contraseña = contraseña;
        this.email = email;
    }

    public Clientes(String nombre) {
        this.nombre = nombre;
    }


    public Clientes(int id_clientes) {
        this.id_clientes = id_clientes;
    }

    public void setId_clientes(int id_clientes) {
        this.id_clientes = id_clientes;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId_clientes() {
        return id_clientes;
    }

    public  String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public  String getContraseña() {
        return contraseña;
    }

    public String getEmail() {
        return email;
    }
}
