package com.example.pcines.modelo.Clases;

import java.time.LocalDateTime;

public class Reserva {
    private int id_reserva;
    private int id_cliente;


    public Reserva(int id_reserva, int id_cliente) {
        this.id_reserva = id_reserva;
        this.id_cliente = id_cliente;

    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public int getId_reserva() {
        return id_reserva;
    }

    public int getId_cliente() {
        return id_cliente;
    }
}
