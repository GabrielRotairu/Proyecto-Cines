package com.example.pcines.modelo.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.pcines.modelo.Clases.Reserva;
import com.example.pcines.modelo.Clases.Clientes;


public class ReservaDao {

	public static void insertarNuevaReserva(Reserva Reserva) {
		try {
			EnlaceJDBC enlace = new EnlaceJDBC();
			String sql = "insert into reservas(Cliente,Proyeccion) values("
					+ Reserva.getId_cliente() +")";
			if (enlace.insertar(sql)) {
				System.out.println("Se ha reservado correctamente ");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static List<Reserva> SeleccionarReserva() {
List<Reserva>listaReserva= new ArrayList<Reserva>();	
ResultSet rs= null;
try {
	EnlaceJDBC enlace= new EnlaceJDBC();
	String sql="SELECT reservas.Cliente,reservas.Peliculas,reservas.Proyeccion from reservas";
	rs=enlace.seleccionRegistros(sql);
	/*while(rs.next()) {
		listaReserva.add(new Reserva(new Clientes(rs.getInt(1)));
	}*/
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
return listaReserva;
	}

	
	
	
}
