package com.example.pcines.modelo.Clases;

import java.time.LocalDate;

public class Peliculas {

    private String nombre;
    private String productora;
    private LocalDate fecha_estreno;
    private int duracion;
    private int id_pelicula;


    public Peliculas(String nombre, String productora, LocalDate fecha_estreno, int duracion, int id_pelicula) {
        this.nombre = nombre;
        this.productora = productora;
        this.fecha_estreno = fecha_estreno;
        this.duracion = duracion;
        this.id_pelicula = id_pelicula;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setProductora(String productora) {
        this.productora = productora;
    }

    public void setFecha_estreno(LocalDate fecha_estreno) {
        this.fecha_estreno = fecha_estreno;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public void setId_pelicula(int id_pelicula) {
        this.id_pelicula = id_pelicula;
    }

    public String getNombre() {
        return nombre;
    }

    public String getProductora() {
        return productora;
    }

    public LocalDate getFecha_estreno() {
        return fecha_estreno;
    }

    public int getDuracion() {
        return duracion;
    }

}
