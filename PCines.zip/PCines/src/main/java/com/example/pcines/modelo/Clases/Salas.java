package com.example.pcines.modelo.Clases;

public class Salas {
    private int numeroSala;
    private String tipoSala;
    private int num_asientos;


    public Salas() {
    }

    public Salas(int numeroSala, String tipoSala, int num_asientos) {
        this.numeroSala = numeroSala;
        this.tipoSala = tipoSala;
        this.num_asientos = num_asientos;
    }

    public void setNumeroSala(int numeroSala) {
        this.numeroSala = numeroSala;
    }

    public void setTipoSala(String tipoSala) {
        this.tipoSala = tipoSala;
    }

    public void setNum_asientos(int num_asientos) {
        this.num_asientos = num_asientos;
    }

    public int getNum_asientos() {
        return num_asientos;
    }

    public int getNumeroSala() {
        return numeroSala;
    }

    public String getTipoSala() {
        return tipoSala;
    }




}
