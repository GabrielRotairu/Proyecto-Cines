package com.example.pcines;

import com.example.pcines.modelo.Clases.Salas;
import com.example.pcines.modelo.Dao.SalasDao;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;



public class SalasController implements Initializable {


@FXML
private ListView<Salas> lstSalas;

@FXML
private ListView<String> lstTipoSalas;

private   List<Salas> listaSalas;
    private   List<String> listTipoSala;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
   /*     listaSalas= new ArrayList<Salas>();
        listaSalas= SalasDao.MostrarSalas();
        lstSalas.getItems().addAll(listaSalas);
       listTipoSala= listaSalas.stream().map(Salas::getTipoSala).collect(Collectors.toList());
        lstTipoSalas.getItems().addAll(listTipoSala);*/
}

}
