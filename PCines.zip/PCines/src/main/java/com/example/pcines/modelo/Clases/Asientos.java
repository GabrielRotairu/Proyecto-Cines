package com.example.pcines.modelo.Clases;

public class Asientos {
    private int id_asiento;
    private int reser_asiento;
    private int sala_asiento;
    private int fila;
    private int columna;

    public Asientos(int id_asiento, int reser_asiento, int sala_asiento, int fila, int columna) {
        this.id_asiento = id_asiento;
        this.reser_asiento = reser_asiento;
        this.sala_asiento = sala_asiento;
        this.fila = fila;
        this.columna = columna;
    }

    public void setId_asiento(int id_asiento) {
        this.id_asiento = id_asiento;
    }

    public void setReser_asiento(int reser_asiento) {
        this.reser_asiento = reser_asiento;
    }

    public void setSala_asiento(int sala_asiento) {
        this.sala_asiento = sala_asiento;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }

    public int getId_asiento() {
        return id_asiento;
    }

    public int getReser_asiento() {
        return reser_asiento;
    }

    public int getSala_asiento() {
        return sala_asiento;
    }

    public int getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }
}
