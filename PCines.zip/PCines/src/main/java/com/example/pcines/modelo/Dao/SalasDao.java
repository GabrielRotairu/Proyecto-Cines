package com.example.pcines.modelo.Dao;

import com.example.pcines.modelo.Clases.Salas;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SalasDao {






        public static List<Salas> MostrarSalas() {
            List<Salas> listaSalas = new ArrayList<Salas>();
            ResultSet rs=null;
            try {
                EnlaceJDBC enlaceBD = new EnlaceJDBC();
                String SqlQuery = "SELECT * FROM salas;";
                rs = enlaceBD.seleccionRegistros(SqlQuery);
                while (rs.next()) {
                    listaSalas.add(new Salas(rs.getInt(1), rs.getString(2), rs.getInt(3)));
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
            return listaSalas;

        }

        public static void insertarSala(Salas s) {
            try {
                EnlaceJDBC enlaceBD = new EnlaceJDBC();
                String sql = "insert into salas (numero_sala, tipo_sala,num_asientos) values (" + s.getNumeroSala() + ",'"
                        + s.getTipoSala() + "'," + s.getNum_asientos()+ ")";
                if (enlaceBD.insertar(sql))
                    System.out.println("La inserción de " + s.getNumeroSala() + s.getTipoSala()+ " se ha realizado correctamente");
            } catch (SQLException e) {

                System.out.println(e.getMessage());
            }

        }



    }


