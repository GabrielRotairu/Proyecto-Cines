package com.example.pcines.modelo.Clases;

import java.time.LocalDateTime;

public class Proyeccion {
    private int id_reserva;
    private LocalDateTime hora;
    private int id_Pelicula;

    public Proyeccion(int id_reserva, LocalDateTime hora, int id_Pelicula) {
        this.id_reserva = id_reserva;
        this.hora = hora;
        this.id_Pelicula = id_Pelicula;
    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public void setHora(LocalDateTime hora) {
        this.hora = hora;
    }

    public void setId_Pelicula(int id_Pelicula) {
        this.id_Pelicula = id_Pelicula;
    }

    public int getId_reserva() {
        return id_reserva;
    }

    public LocalDateTime getHora() {
        return hora;
    }

    public int getId_Pelicula() {
        return id_Pelicula;
    }

}
