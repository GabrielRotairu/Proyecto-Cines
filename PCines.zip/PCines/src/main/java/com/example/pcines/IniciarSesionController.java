package com.example.pcines;

import com.example.pcines.modelo.Clases.Clientes;
import com.example.pcines.modelo.Dao.ClientesDao;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class IniciarSesionController {

    @FXML
    private Button btnLog;

    @FXML
    private TextField TxtUsuario;

    @FXML
    private PasswordField PwdContra;

    public void IniciarSesion(ActionEvent actionEvent) throws IOException {
    if(TxtUsuario.getText().equals("admin")&&PwdContra.getText().equals("admin")){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 500, 400);
        Stage stage = (Stage) TxtUsuario.getScene().getWindow();
        stage.setResizable(false);
        stage.setTitle("SJG Cines");
        stage.setScene(scene);
        stage.show();
    }
/*else if(TxtUsuario.getText().equals(ClientesDao.VerUsuario())&&PwdContra.getText().equals(ClientesDao.VerContra())){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Menu-usuarios-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 500, 400);
        Stage stage = (Stage) TxtUsuario.getScene().getWindow();
        stage.setResizable(false);
        stage.setTitle("SJG Cines");
        stage.setScene(scene);
        stage.show();
       }*/
    else if(TxtUsuario.getText().equals("cliente")&&PwdContra.getText().equals("cliente")){
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Menu-usuarios-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        Stage stage = (Stage) TxtUsuario.getScene().getWindow();
        stage.setResizable(false);
        stage.setTitle("SJG Cines");
        stage.setScene(scene);
        stage.show();
    }
else {
        System.out.println("El usuario o contraseñas introducidas no concuerdan ni con el Administrador ni con Cliente");
    }
    }


}
