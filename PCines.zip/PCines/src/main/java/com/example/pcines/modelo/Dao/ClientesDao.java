package com.example.pcines.modelo.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.pcines.modelo.Clases.Clientes;
import com.example.pcines.modelo.Clases.Salas;


public class ClientesDao {

	public static List<Clientes> SeleccionarClientes() {
		List<Clientes> listaClientes = new ArrayList<Clientes>();
		ResultSet rs = null;
		try {
			EnlaceJDBC enlace = new EnlaceJDBC();
			String sql = "select * from clientes";
			rs = enlace.seleccionRegistros(sql);
			while (rs.next()) {
				listaClientes.add(
						new Clientes(rs.getInt(1),rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5)));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listaClientes;
	}

	public static  List<Clientes> VerUsuario(){
List<Clientes> listaUsuario= new ArrayList<Clientes>();
ResultSet rs= null;
		try {
			EnlaceJDBC enlace = new EnlaceJDBC();
			String sql= "Select nombre from clientes";
			rs= enlace.seleccionRegistros(sql);
			while (rs.next()){
				listaUsuario.add(new Clientes(rs.getString(2)));
			}

		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		return listaUsuario;
	}

	public static List<Clientes> VerContra(){
	List<Clientes> listaContra= new ArrayList<Clientes>();
ResultSet rs= null;
		try {
			EnlaceJDBC enlace = new EnlaceJDBC();
			String sql="Select contraseña from clientes";
			rs= enlace.seleccionRegistros(sql);

			while (rs.next()){
				listaContra.add(new Clientes(rs.getString(4)));
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

		return listaContra;
	}

	public static void InsertarNuevoCliente(Clientes Clientes) {
		ResultSet rs = null;
		try {
			EnlaceJDBC enlace = new EnlaceJDBC();
			String sql = "insert into clientes(nombre,apellidos,contraseña,email) values('" + Clientes.getNombre()
					+ "','" + Clientes.getApellidos() +"','"+Clientes.getContraseña()+ "','" + Clientes.getEmail() + "',"
					+   ")";
			if (enlace.insertar(sql)) {
				System.out
						.println("Se ha insertado correctamente: " + Clientes.getNombre() + " , " + Clientes.getApellidos());
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}




	
	
	
	

}
